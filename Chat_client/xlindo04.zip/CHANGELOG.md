# Changelog

### Limitations

- [Limitation] After an error ending, the application may encounter difficulties in clearing or resetting the stdin buffer, while not sending messages in waitng for reply to join.
